import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private isAuthenticatedUser = false;
  private readonly DEMO_USERNAME = 'admin';
  private readonly DEMO_PASSWORD = 'admin';

  constructor() {
    // Check if user was previously logged in
    this.isAuthenticatedUser = localStorage.getItem('isAuthenticated') === 'true';
  }

  login(username: string, password: string): boolean {
    if (username === this.DEMO_USERNAME && password === this.DEMO_PASSWORD) {
      this.isAuthenticatedUser = true;
      localStorage.setItem('isAuthenticated', 'true');
      return true;
    }
    return false;
  }

  logout(): void {
    this.isAuthenticatedUser = false;
    localStorage.removeItem('isAuthenticated');
  }

  isAuthenticated(): boolean {
    return this.isAuthenticatedUser;
  }
}
