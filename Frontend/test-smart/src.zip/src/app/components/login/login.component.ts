import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.scss'
})
export class LoginComponent implements OnInit {
  username: string = '';
  password: string = '';
  errorMessage: string = '';
  isLoading: boolean = false;

  leftMessages = [
    'TESSA - Total End-to-End System Automation',
    'Testing Every System Always',
    'Unified automation platform for complete testing',
    'From first trigger to final validation'
  ];

  rightMessages = [
    'AI-powered test generation and execution',
    '4 intelligent agents working in harmony',
    'Real-time monitoring and insights',
    'Complete test automation lifecycle'
  ];

  currentLeftMessage = '';
  currentRightMessage = '';
  leftMessageIndex = 0;
  rightMessageIndex = 0;

  constructor(
    private authService: AuthService,
    private router: Router
  ) {}

  ngOnInit() {
    this.startTypingAnimation();
  }

  async startTypingAnimation() {
    while (true) {
      // Type left message
      await this.typeMessage(this.leftMessages[this.leftMessageIndex], 'left');
      await this.delay(3000);
      await this.eraseMessage('left');
      this.leftMessageIndex = (this.leftMessageIndex + 1) % this.leftMessages.length;
      
      await this.delay(500);
      
      // Type right message
      await this.typeMessage(this.rightMessages[this.rightMessageIndex], 'right');
      await this.delay(3000);
      await this.eraseMessage('right');
      this.rightMessageIndex = (this.rightMessageIndex + 1) % this.rightMessages.length;
      
      await this.delay(500);
    }
  }

  async typeMessage(message: string, side: 'left' | 'right') {
    for (let i = 0; i <= message.length; i++) {
      if (side === 'left') {
        this.currentLeftMessage = message.substring(0, i);
      } else {
        this.currentRightMessage = message.substring(0, i);
      }
      await this.delay(50);
    }
  }

  async eraseMessage(side: 'left' | 'right') {
    const message = side === 'left' ? this.currentLeftMessage : this.currentRightMessage;
    for (let i = message.length; i >= 0; i--) {
      if (side === 'left') {
        this.currentLeftMessage = message.substring(0, i);
      } else {
        this.currentRightMessage = message.substring(0, i);
      }
      await this.delay(30);
    }
  }

  delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  onLogin() {
    this.errorMessage = '';
    this.isLoading = true;

    setTimeout(() => {
      if (this.authService.login(this.username, this.password)) {
        this.router.navigate(['/home']);
      } else {
        this.errorMessage = 'Invalid username or password';
        this.isLoading = false;
      }
    }, 500);
  }
}
