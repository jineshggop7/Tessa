import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { ApiService, ExecutionHistoryItem, TestScenario, ExecutionResult } from '../../services/api.service';
import { ExecutionStateService } from '../../services/execution-state.service';

@Component({
  selector: 'app-execution-progress',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './execution-progress.component.html',
  styleUrl: './execution-progress.component.scss'
})
export class ExecutionProgressComponent implements OnInit, OnDestroy {
  executionId: string = '';
  execution: ExecutionHistoryItem | null = null;
  testScenarios: TestScenario[] = [];
  executionResults: ExecutionResult[] = [];
  logMessages: string[] = [];
  wsConnected: boolean = false;
  
  private subscriptions: Subscription[] = [];

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private apiService: ApiService,
    private stateService: ExecutionStateService
  ) {}

  ngOnInit() {
    this.executionId = this.route.snapshot.params['id'];
    
    // Subscribe to state changes
    this.subscriptions.push(
      this.stateService.currentExecution$.subscribe(exec => {
        this.execution = exec;
      }),
      this.stateService.testScenarios$.subscribe(scenarios => {
        this.testScenarios = scenarios;
      }),
      this.stateService.executionResults$.subscribe(results => {
        this.executionResults = results;
      }),
      this.stateService.logMessages$.subscribe(logs => {
        this.logMessages = logs;
      }),
      this.stateService.wsConnected$.subscribe(connected => {
        this.wsConnected = connected;
      })
    );

    // Connect to WebSocket
    this.stateService.connectToExecution(this.executionId);

    // Load initial data
    this.loadExecutionData();
  }

  ngOnDestroy() {
    this.subscriptions.forEach(sub => sub.unsubscribe());
    this.stateService.disconnectWebSocket();
  }

  loadExecutionData() {
    this.apiService.getExecutionHistory(100, 0).subscribe({
      next: (response) => {
        const execution = response.executions.find(e => e.execution_id === this.executionId);
        if (execution) {
          this.stateService.setCurrentExecution(execution);
        }
      },
      error: (err) => console.error('Error loading execution:', err)
    });
  }

  viewReport() {
    this.router.navigate(['/report', this.executionId]);
  }

  getStatusIcon(status: string): string {
    const icons: any = {
      'pending': '⏳',
      'started': '🚀',
      'testcase_generation': '🤖',
      'code_generation': '📝',
      'execution': '⚡',
      'completed': '✅',
      'failed': '❌'
    };
    return icons[status] || '❓';
  }

  getStatusText(status: string): string {
    const texts: any = {
      'pending': 'Pending',
      'started': 'Started',
      'testcase_generation': 'Generating Test Scenarios',
      'code_generation': 'Generating Automation Code',
      'execution': 'Executing Tests',
      'completed': 'Completed',
      'failed': 'Failed'
    };
    return texts[status] || status.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
  }

  getStatusDescription(status: string): string {
    const descriptions: any = {
      'pending': 'Execution is queued and will start soon',
      'started': 'Execution has started',
      'testcase_generation': 'AI Agent 1 is analyzing requirements and generating test scenarios',
      'code_generation': 'AI Agent 2 is creating Python automation scripts',
      'execution': 'AI Agent 3 is running automated tests',
      'completed': 'All tests have been executed successfully',
      'failed': 'Execution encountered an error'
    };
    return descriptions[status] || '';
  }

  getProgressPercentage(): number {
    if (!this.execution) return 0;
    
    const statusProgress: any = {
      'pending': 0,
      'started': 10,
      'testcase_generation': 30,
      'code_generation': 60,
      'execution': 80,
      'completed': 100,
      'failed': 100
    };
    
    return statusProgress[this.execution.status] || 0;
  }

  getScenarioStatusIcon(scenarioId: string): string {
    const result = this.getScenarioResult(scenarioId);
    if (!result) return '⏳';
    
    const icons: any = {
      'PASSED': '✅',
      'FAILED': '❌',
      'ERROR': '⚠️'
    };
    return icons[result.result] || '❓';
  }

  getScenarioResult(scenarioId: string): ExecutionResult | null {
    return this.executionResults.find(r => r.scenario_id === scenarioId) || null;
  }

  getPassedCount(): number {
    return this.executionResults.filter(r => r.result === 'PASSED').length;
  }

  getFailedCount(): number {
    return this.executionResults.filter(r => r.result === 'FAILED' || r.result === 'ERROR').length;
  }

  getPendingCount(): number {
    return this.testScenarios.length - this.executionResults.length;
  }
}
