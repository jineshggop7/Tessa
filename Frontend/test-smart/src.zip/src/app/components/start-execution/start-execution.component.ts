import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService, StartExecutionRequest } from '../../services/api.service';
import { ExecutionStateService } from '../../services/execution-state.service';
import { Router } from '@angular/router';

interface FileWithPath extends File {
  path?: string;
}

@Component({
  selector: 'app-start-execution',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './start-execution.component.html',
  styleUrl: './start-execution.component.scss'
})
export class StartExecutionComponent {
  appName: string = '';
  appDescription: string = '';
  appPlatform: string = 'web';
  aiModel: string = 'gemini';
  customPrompt: string = '';
  selectedFiles: FileWithPath[] = [];
  isLoading: boolean = false;
  error: string = '';

  platforms = ['web', 'mobile', 'desktop'];
  aiModels = ['gemini', 'gpt', 'openai', 'gpt-4'];

  constructor(
    private apiService: ApiService,
    private stateService: ExecutionStateService,
    private router: Router
  ) {}

  onFileSelect(event: any) {
    const files = Array.from(event.target.files) as FileWithPath[];
    // Append new files to existing selection instead of replacing
    this.selectedFiles = [...this.selectedFiles, ...files];
    console.log('Selected files:', this.selectedFiles);
    // Reset the input so the same file can be selected again if needed
    event.target.value = '';
  }

  removeFile(index: number) {
    this.selectedFiles.splice(index, 1);
  }

  formatFileSize(bytes: number): string {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  }

  startExecution() {
    // Validate required fields
    if (!this.appName) {
      this.error = 'Application name is required';
      return;
    }

    if (this.selectedFiles.length === 0) {
      this.error = 'At least one image file is required';
      return;
    }

    // Extract image paths from selected files
    const imagePathArray = this.selectedFiles
      .map(file => file.path || file.name)
      .filter(path => path && path.length > 0);

    console.log('Selected files with paths:', this.selectedFiles);
    console.log('Sending request with image paths:', imagePathArray);

    this.isLoading = true;
    this.error = '';

    const requestData: StartExecutionRequest = {
      image_paths: imagePathArray,
      app_name: this.appName,
      app_platform: this.appPlatform,
      ai_model: this.aiModel
    };

    // Add optional fields
    if (this.appDescription) {
      requestData.app_description = this.appDescription;
    }

    if (this.customPrompt) {
      requestData.custom_prompt = this.customPrompt;
    }

    this.apiService.startExecution(requestData).subscribe({
      next: (response) => {
        console.log('Execution started:', response);
        // Navigate to progress page
        this.router.navigate(['/execution', response.execution_id]);
      },
      error: (err) => {
        console.error('Error starting execution:', err);
        this.error = err.error?.detail || 'Failed to start execution';
        this.isLoading = false;
      }
    });
  }

  stopExecution() {
    // TODO: Implement stop execution logic
    console.log('Stop execution clicked');
  }
}
