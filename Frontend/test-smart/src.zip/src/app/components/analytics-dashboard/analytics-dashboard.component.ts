import { Component, OnInit, ViewChild, ElementRef, AfterViewInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ApiService, ExecutionHistoryItem } from '../../services/api.service';
import { Chart, ChartConfiguration, registerables } from 'chart.js';

Chart.register(...registerables);

@Component({
  selector: 'app-analytics-dashboard',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './analytics-dashboard.component.html',
  styleUrl: './analytics-dashboard.component.scss'
})
export class AnalyticsDashboardComponent implements OnInit, AfterViewInit {
  @ViewChild('lineChart') lineChartRef!: ElementRef<HTMLCanvasElement>;
  @ViewChild('pieChart') pieChartRef!: ElementRef<HTMLCanvasElement>;
  @ViewChild('barChart') barChartRef!: ElementRef<HTMLCanvasElement>;
  @ViewChild('barChart2') barChart2Ref!: ElementRef<HTMLCanvasElement>;

  isLoading: boolean = false;
  error: string = '';
  executionHistory: ExecutionHistoryItem[] = [];

  // Summary stats
  totalExecutions: number = 0;
  successRate: number = 0;
  avgTestScenarios: number = 0;
  totalTestCases: number = 0;

  private charts: Chart[] = [];

  constructor(private apiService: ApiService) {}

  ngOnInit() {
    this.loadAnalyticsData();
  }

  ngAfterViewInit() {
    // Charts will be initialized after data is loaded
  }

  loadAnalyticsData() {
    this.isLoading = true;
    this.error = '';

    this.apiService.getExecutionHistory(100, 0).subscribe({
      next: (response) => {
        this.executionHistory = response.executions;
        this.calculateStats();
        this.initializeCharts();
        this.isLoading = false;
      },
      error: (err) => {
        console.error('Error loading analytics data:', err);
        this.error = err.error?.detail || 'Failed to load analytics data';
        this.isLoading = false;
      }
    });
  }

  refreshData() {
    this.destroyCharts();
    this.loadAnalyticsData();
  }

  calculateStats() {
    this.totalExecutions = this.executionHistory.length;

    if (this.totalExecutions === 0) {
      this.successRate = 0;
      this.avgTestScenarios = 0;
      this.totalTestCases = 0;
      return;
    }

    // Calculate success rate
    const successfulExecutions = this.executionHistory.filter(
      exec => exec.overall_result?.toLowerCase() === 'passed' || exec.status === 'completed'
    ).length;
    this.successRate = Math.round((successfulExecutions / this.totalExecutions) * 100);

    // Calculate average test scenarios
    const totalScenarios = this.executionHistory.reduce(
      (sum, exec) => sum + (exec.test_scenarios?.length || 0), 0
    );
    this.avgTestScenarios = Math.round(totalScenarios / this.totalExecutions);

    // Calculate total test cases
    this.totalTestCases = this.executionHistory.reduce(
      (sum, exec) => sum + (exec.execution_results?.length || 0), 0
    );
  }

  initializeCharts() {
    setTimeout(() => {
      if (this.lineChartRef && this.pieChartRef && this.barChartRef && this.barChart2Ref) {
        this.createLineChart();
        this.createPieChart();
        this.createBarChart();
        this.createBarChart2();
      }
    }, 100);
  }

  createLineChart() {
    const ctx = this.lineChartRef.nativeElement.getContext('2d');
    if (!ctx) return;

    // Group executions by date
    const dateMap = new Map<string, { total: number, passed: number, failed: number }>();
    
    this.executionHistory.forEach(exec => {
      const date = new Date(exec.created_at).toLocaleDateString();
      if (!dateMap.has(date)) {
        dateMap.set(date, { total: 0, passed: 0, failed: 0 });
      }
      const stats = dateMap.get(date)!;
      stats.total++;
      if (exec.overall_result?.toLowerCase() === 'passed' || exec.status === 'completed') {
        stats.passed++;
      } else {
        stats.failed++;
      }
    });

    const sortedDates = Array.from(dateMap.keys()).sort((a, b) => 
      new Date(a).getTime() - new Date(b).getTime()
    ).slice(-10); // Last 10 dates

    const config: ChartConfiguration = {
      type: 'line',
      data: {
        labels: sortedDates,
        datasets: [
          {
            label: 'Passed',
            data: sortedDates.map(date => dateMap.get(date)!.passed),
            borderColor: '#22c55e',
            backgroundColor: 'rgba(34, 197, 94, 0.1)',
            tension: 0.4,
            fill: true
          },
          {
            label: 'Failed',
            data: sortedDates.map(date => dateMap.get(date)!.failed),
            borderColor: '#ef4444',
            backgroundColor: 'rgba(239, 68, 68, 0.1)',
            tension: 0.4,
            fill: true
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: true,
        plugins: {
          legend: {
            display: true,
            position: 'top'
          },
          title: {
            display: false
          }
        },
        scales: {
          y: {
            beginAtZero: true,
            ticks: {
              stepSize: 1
            }
          }
        }
      }
    };

    this.charts.push(new Chart(ctx, config));
  }

  createPieChart() {
    const ctx = this.pieChartRef.nativeElement.getContext('2d');
    if (!ctx) return;

    // Count executions by platform
    const platformCounts = new Map<string, number>();
    this.executionHistory.forEach(exec => {
      const platform = exec.app_platform || 'unknown';
      platformCounts.set(platform, (platformCounts.get(platform) || 0) + 1);
    });

    const config: ChartConfiguration = {
      type: 'pie',
      data: {
        labels: Array.from(platformCounts.keys()),
        datasets: [{
          data: Array.from(platformCounts.values()),
          backgroundColor: [
            '#3b82f6',
            '#8b5cf6',
            '#ec4899',
            '#f59e0b',
            '#10b981'
          ],
          borderWidth: 2,
          borderColor: '#fff'
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: true,
        plugins: {
          legend: {
            display: true,
            position: 'right'
          }
        }
      }
    };

    this.charts.push(new Chart(ctx, config));
  }

  createBarChart() {
    const ctx = this.barChartRef.nativeElement.getContext('2d');
    if (!ctx) return;

    // Count results by platform
    const platformStats = new Map<string, { passed: number, failed: number }>();
    this.executionHistory.forEach(exec => {
      const platform = exec.app_platform || 'unknown';
      if (!platformStats.has(platform)) {
        platformStats.set(platform, { passed: 0, failed: 0 });
      }
      const stats = platformStats.get(platform)!;
      if (exec.overall_result?.toLowerCase() === 'passed' || exec.status === 'completed') {
        stats.passed++;
      } else {
        stats.failed++;
      }
    });

    const config: ChartConfiguration = {
      type: 'bar',
      data: {
        labels: Array.from(platformStats.keys()),
        datasets: [
          {
            label: 'Passed',
            data: Array.from(platformStats.values()).map(s => s.passed),
            backgroundColor: '#22c55e',
            borderRadius: 6
          },
          {
            label: 'Failed',
            data: Array.from(platformStats.values()).map(s => s.failed),
            backgroundColor: '#ef4444',
            borderRadius: 6
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: true,
        plugins: {
          legend: {
            display: true,
            position: 'top'
          }
        },
        scales: {
          y: {
            beginAtZero: true,
            ticks: {
              stepSize: 1
            }
          }
        }
      }
    };

    this.charts.push(new Chart(ctx, config));
  }

  createBarChart2() {
    const ctx = this.barChart2Ref.nativeElement.getContext('2d');
    if (!ctx) return;

    // Count success rate by AI model
    const modelStats = new Map<string, { passed: number, total: number }>();
    this.executionHistory.forEach(exec => {
      const model = exec.ai_model || 'unknown';
      if (!modelStats.has(model)) {
        modelStats.set(model, { passed: 0, total: 0 });
      }
      const stats = modelStats.get(model)!;
      stats.total++;
      if (exec.overall_result?.toLowerCase() === 'passed' || exec.status === 'completed') {
        stats.passed++;
      }
    });

    const successRates = new Map<string, number>();
    modelStats.forEach((stats, model) => {
      successRates.set(model, Math.round((stats.passed / stats.total) * 100));
    });

    const config: ChartConfiguration = {
      type: 'bar',
      data: {
        labels: Array.from(successRates.keys()),
        datasets: [{
          label: 'Success Rate (%)',
          data: Array.from(successRates.values()),
          backgroundColor: [
            '#6366f1',
            '#8b5cf6',
            '#ec4899',
            '#f59e0b'
          ],
          borderRadius: 6
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: true,
        plugins: {
          legend: {
            display: false
          }
        },
        scales: {
          y: {
            beginAtZero: true,
            max: 100,
            ticks: {
              callback: function(value) {
                return value + '%';
              }
            }
          }
        }
      }
    };

    this.charts.push(new Chart(ctx, config));
  }

  destroyCharts() {
    this.charts.forEach(chart => chart.destroy());
    this.charts = [];
  }

  ngOnDestroy() {
    this.destroyCharts();
  }
}
