import { Component, OnInit, Inject, PLATFORM_ID } from '@angular/core';
import { CommonModule, isPlatformBrowser } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService, AskTessaRequest } from '../../services/api.service';

interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

@Component({
  selector: 'app-tessa-chatbot',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './tessa-chatbot.component.html',
  styleUrl: './tessa-chatbot.component.scss'
})
export class TessaChatbotComponent implements OnInit {
  messages: ChatMessage[] = [];
  currentMessage: string = '';
  isLoading: boolean = false;
  executionId: string = '';
  aiModel: string = 'gemini';
  
  aiModels = ['gemini', 'gpt', 'openai', 'gpt-4'];

  constructor(
    private apiService: ApiService,
    @Inject(PLATFORM_ID) private platformId: Object
  ) {}

  ngOnInit() {
    // Load chat history from localStorage only in browser
    if (isPlatformBrowser(this.platformId)) {
      const saved = localStorage.getItem('tessa_messages');
      if (saved) {
        this.messages = JSON.parse(saved).map((msg: any) => ({
          ...msg,
          timestamp: new Date(msg.timestamp)
        }));
      }
      
      const savedExecutionId = localStorage.getItem('tessa_execution_id');
      if (savedExecutionId) {
        this.executionId = savedExecutionId;
      }

      const savedAiModel = localStorage.getItem('tessa_ai_model');
      if (savedAiModel) {
        this.aiModel = savedAiModel;
      }
    }
  }

  setExecutionId() {
    if (isPlatformBrowser(this.platformId)) {
      localStorage.setItem('tessa_execution_id', this.executionId);
    }
  }

  setAiModel() {
    if (isPlatformBrowser(this.platformId)) {
      localStorage.setItem('tessa_ai_model', this.aiModel);
    }
  }

  sendMessage() {
    if (!this.currentMessage.trim() || this.isLoading) return;

    if (!this.executionId.trim()) {
      alert('Please enter an Execution ID first');
      return;
    }

    const userMessage: ChatMessage = {
      role: 'user',
      content: this.currentMessage.trim(),
      timestamp: new Date()
    };

    this.messages.push(userMessage);
    this.saveMessages();

    const question = this.currentMessage;
    this.currentMessage = '';
    this.isLoading = true;

    const request: AskTessaRequest = {
      execution_id: this.executionId,
      message: question,
      ai_model: this.aiModel
    };

    this.apiService.askTessa(request).subscribe({
      next: (response) => {
        const assistantMessage: ChatMessage = {
          role: 'assistant',
          content: response.response,
          timestamp: new Date(response.timestamp)
        };
        this.messages.push(assistantMessage);
        this.saveMessages();
        this.isLoading = false;
        this.scrollToBottom();
      },
      error: (err) => {
        console.error('Error asking Tessa:', err);
        const errorMessage: ChatMessage = {
          role: 'assistant',
          content: err.error?.detail || 'Sorry, I encountered an error. Please try again.',
          timestamp: new Date()
        };
        this.messages.push(errorMessage);
        this.isLoading = false;
        this.scrollToBottom();
      }
    });

    this.scrollToBottom();
  }

  clearConversation() {
    if (confirm('Are you sure you want to clear the conversation?')) {
      this.messages = [];
      if (isPlatformBrowser(this.platformId)) {
        localStorage.removeItem('tessa_messages');
      }
    }
  }

  formatTime(date: Date): string {
    return new Date(date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  }

  private saveMessages() {
    if (isPlatformBrowser(this.platformId)) {
      localStorage.setItem('tessa_messages', JSON.stringify(this.messages));
    }
  }

  private scrollToBottom() {
    setTimeout(() => {
      const container = document.querySelector('.chat-messages');
      if (container) {
        container.scrollTop = container.scrollHeight;
      }
    }, 100);
  }
}
